"""
CodeAlpha Analytics - Web Scraper & Data Collector
Collects publicly available data from CodeAlpha platform
"""
import asyncio
import json
import re
from playwright.async_api import async_playwright


class CodeAlphaScraper:
    def __init__(self):
        self.data = {}

    async def scrape(self):
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()
            await page.goto("https://www.codealpha.tech/", wait_until="networkidle")
            await page.wait_for_timeout(3000)

            self.data["url"] = page.url
            self.data["title"] = await page.title()

            # Get all visible text
            body_text = await page.inner_text("body")
            self.data["full_text"] = body_text

            # Extract metrics section
            sections = await page.query_selector_all("section")
            for i, section in enumerate(sections):
                text = (await section.inner_text()).strip()
                if "METRICS" in text and "Students Joined" in text:
                    self.data["metrics_raw"] = text
                if "Explore Our Internship Programs" in text:
                    self.data["internships_raw"] = text
                if "AI Career Tools" in text or "CAREER BOOSTERS" in text:
                    self.data["tools_raw"] = text

            # Extract header/nav links for services
            nav_links = await page.query_selector_all("nav a, header a")
            self.data["nav_links"] = [(await el.inner_text()).strip() for el in nav_links]

            await browser.close()
        return self.data

    def parse_services(self):
        text = self.data.get("full_text", "")

        # Internship domains
        known_domains = [
            "Web Development", "App Development", "Machine Learning",
            "Python", "Java", "Data Science", "Artificial Intelligence",
            "Cyber Security", "UI/UX Design", "Frontend Development",
            "Backend Development", "Full Stack Development"
        ]
        found_domains = []
        for d in known_domains:
            if d.lower() in text.lower():
                found_domains.append(d)

        # Career tools
        tools = re.findall(r'(ATS Score|AI Resume Scanner|Job Email Builder|Student Dashboard)', text, re.I)
        tools = list(set(t.strip() for t in tools))

        # Key features mentioned
        features = []
        feature_keywords = [
            "Verified Certificate", "Offer Letter", "Letter of Recommendation",
            "Flexible Schedule", "Real Projects", "Portfolio Building",
            "Mentor Support", "Free Internship", "Remote Internship",
            "Unique Verification ID", "Project-Based Learning"
        ]
        for f in feature_keywords:
            if f.lower() in text.lower():
                features.append(f)

        return {
            "internship_domains": found_domains,
            "career_tools": tools,
            "features": features,
            "total_domains": len(found_domains),
            "total_tools": len(tools),
            "total_features": len(features)
        }

    def parse_metrics(self):
        """Extract any numeric data from the page"""
        text = self.data.get("metrics_raw", "") + "\n" + self.data.get("full_text", "")
        metrics = {}

        # Look for numbers next to known labels
        patterns = {
            "students_joined": r'(\d[\d,]*\+?)\s*Students\s*Joined',
            "certificates_issued": r'(\d[\d,]*\+?)\s*Certificates\s*Issued',
            "services_count": r'(\d[\d,]*\+?)\s*Services',
            "countries": r'(\d[\d,]*\+?)\s*Countries',
        }
        for key, pattern in patterns.items():
            match = re.search(pattern, text, re.I)
            if match:
                metrics[key] = match.group(1)

        # Meta description
        meta_students = re.search(r'Join\s*([\d,.]+[KkMmBb+]?)\s*[+]?\s*students', text, re.I)
        if meta_students:
            metrics["students_meta"] = meta_students.group(1)

        return metrics


async def main():
    scraper = CodeAlphaScraper()
    await scraper.scrape()

    services = scraper.parse_services()
    metrics = scraper.parse_metrics()

    result = {
        "platform": {
            "name": "CodeAlpha",
            "tagline": "#1 Platform for Virtual Internships",
            "founded": 2022,
            "headquarters": "Lucknow, India",
            "linkedin_followers": "500K+",
        },
        "metrics": metrics,
        "services": services,
    }

    with open("codealpha_analytics.json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(json.dumps(result, indent=2))
    return result

if __name__ == "__main__":
    asyncio.run(main())
