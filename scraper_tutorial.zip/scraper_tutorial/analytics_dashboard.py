"""
CodeAlpha Analytics Dashboard
Generates visualizations and insights from scraped CodeAlpha data
"""
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from collections import Counter
import os

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.size"] = 11
plt.rcParams["figure.facecolor"] = "#f8fafc"
plt.rcParams["axes.facecolor"] = "#ffffff"
plt.rcParams["axes.grid"] = True
plt.rcParams["grid.alpha"] = 0.3

OUTPUT_DIR = "analytics_output"
os.makedirs(OUTPUT_DIR, exist_ok=True)


def load_data():
    with open("codealpha_analytics.json", "r", encoding="utf-8") as f:
        return json.load(f)


def chart_internship_domains(data):
    domains = data["services"]["internship_domains"]
    categories = {}
    for d in domains:
        d_lower = d.lower()
        if "web" in d_lower or "frontend" in d_lower:
            categories.setdefault("Web/Frontend", []).append(d)
        elif "app" in d_lower or "mobile" in d_lower:
            categories.setdefault("Mobile", []).append(d)
        elif "ml" in d_lower or "machine" in d_lower or "ai" in d_lower or "data" in d_lower:
            categories.setdefault("AI/ML/Data", []).append(d)
        elif "python" in d_lower or "java" in d_lower or "back" in d_lower:
            categories.setdefault("Backend/Language", []).append(d)
        elif "cyber" in d_lower or "security" in d_lower:
            categories.setdefault("Security", []).append(d)
        elif "ui" in d_lower or "ux" in d_lower or "design" in d_lower:
            categories.setdefault("Design", []).append(d)
        else:
            categories.setdefault("Other", []).append(d)

    labels = list(categories.keys())
    values = [len(v) for v in categories.values()]
    colors = ["#3b82f6", "#8b5cf6", "#06b6d4", "#f59e0b", "#ef4444", "#10b981", "#ec4899"]

    fig, ax = plt.subplots(figsize=(10, 6))
    bars = ax.barh(labels, values, color=colors[:len(labels)], height=0.6)

    for bar, val in zip(bars, values):
        ax.text(bar.get_width() + 0.1, bar.get_y() + bar.get_height()/2,
                str(val), va="center", fontweight="bold", fontsize=13)

    ax.set_xlabel("Number of Domains", fontweight="bold")
    ax.set_title("CodeAlpha Internship Domains by Category", fontweight="bold", fontsize=15, pad=15)
    ax.set_xlim(0, max(values) + 2)
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)

    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "internship_domains.png")
    fig.savefig(path, dpi=150)
    plt.close()
    print(f"  Saved: {path}")


def chart_features_radar(data):
    features = data["services"]["features"]
    tools = data["services"]["career_tools"]
    domains = data["services"]["internship_domains"]

    # Count metrics
    categories = ["Internship\nDomains", "Career\nTools", "Key\nFeatures"]
    values = [len(domains), len(tools), len(features)]

    fig, ax = plt.subplots(figsize=(8, 6))
    colors = ["#3b82f6", "#10b981", "#f59e0b"]
    bars = ax.bar(categories, values, color=colors, width=0.5, edgecolor="white", linewidth=2)

    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.2,
                str(val), ha="center", va="bottom", fontweight="bold", fontsize=18)

    ax.set_ylabel("Count", fontweight="bold", fontsize=12)
    ax.set_title("CodeAlpha Platform Overview", fontweight="bold", fontsize=15, pad=15)
    ax.set_ylim(0, max(values) + 3)
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)

    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "platform_overview.png")
    fig.savefig(path, dpi=150)
    plt.close()
    print(f"  Saved: {path}")


def chart_services_detail(data):
    fig, axes = plt.subplots(1, 3, figsize=(14, 5))

    # 1. Internship Domains
    domains = data["services"]["internship_domains"]
    ax = axes[0]
    colors = plt.cm.viridis(np.linspace(0.2, 0.9, len(domains)))
    bars = ax.barh(domains, [1]*len(domains), color=colors, height=0.6)
    ax.set_title("Internship Domains", fontweight="bold", fontsize=12)
    ax.tick_params(labelsize=8)
    ax.set_xlim(0, 1.5)
    ax.set_xticks([])
    for spine in ["top", "right", "bottom"]:
        ax.spines[spine].set_visible(False)
    for bar in bars:
        ax.text(0.05, bar.get_y() + bar.get_height()/2, "Available",
                va="center", fontsize=7, color="#555")

    # 2. Career Tools
    tools = data["services"]["career_tools"]
    ax = axes[1]
    colors = plt.cm.plasma(np.linspace(0.2, 0.9, len(tools)))
    bars = ax.barh(tools, [1]*len(tools), color=colors, height=0.6)
    ax.set_title("Free AI Career Tools", fontweight="bold", fontsize=12)
    ax.tick_params(labelsize=8)
    ax.set_xlim(0, 1.5)
    ax.set_xticks([])
    for spine in ["top", "right", "bottom"]:
        ax.spines[spine].set_visible(False)
    for bar in bars:
        ax.text(0.05, bar.get_y() + bar.get_height()/2, "Free",
                va="center", fontsize=7, color="#555")

    # 3. Key Features
    features = data["services"]["features"]
    ax = axes[2]
    colors = plt.cm.cool(np.linspace(0.2, 0.9, len(features)))
    bars = ax.barh(features, [1]*len(features), color=colors, height=0.6)
    ax.set_title("Key Features & Benefits", fontweight="bold", fontsize=12)
    ax.tick_params(labelsize=8)
    ax.set_xlim(0, 1.5)
    ax.set_xticks([])
    for spine in ["top", "right", "bottom"]:
        ax.spines[spine].set_visible(False)
    for bar in bars:
        ax.text(0.05, bar.get_y() + bar.get_height()/2, "Included",
                va="center", fontsize=7, color="#555")

    plt.suptitle("CodeAlpha Services & Features Breakdown", fontweight="bold", fontsize=15, y=1.02)
    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "services_breakdown.png")
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Saved: {path}")


def chart_metrics_card(data):
    """Create a KPI-style metrics card"""
    metrics = data["metrics"]
    platform = data["platform"]

    fig, ax = plt.subplots(figsize=(10, 3))
    ax.axis("off")

    # Layout cells
    cells = [
        ("Platform", "CodeAlpha"),
        ("Founded", str(platform.get("founded", "N/A"))),
        ("LinkedIn", platform.get("linkedin_followers", "N/A")),
        ("Domains", str(data["services"]["total_domains"])),
        ("Tools", str(data["services"]["total_tools"])),
        ("Features", str(data["services"]["total_features"])),
    ]

    # Draw table
    table = ax.table(cellText=cells, colLabels=["Metric", "Value"],
                     loc="center", cellLoc="center")
    table.auto_set_font_size(False)
    table.set_fontsize(12)
    table.scale(1.2, 1.8)

    for key, cell in table.get_celld().items():
        if key[0] == 0:
            cell.set_facecolor("#1e293b")
            cell.set_text_props(color="white", fontweight="bold")
        elif key[1] == 0:
            cell.set_facecolor("#f1f5f9")
            cell.set_text_props(fontweight="bold")
        else:
            cell.set_facecolor("#ffffff")
            cell.set_text_props(color="#0284c7", fontweight="bold")

    ax.set_title("CodeAlpha - Key Metrics Summary", fontweight="bold", fontsize=14, pad=20)
    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "kpi_summary.png")
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Saved: {path}")


def generate_report(data):
    """Generate text report"""
    lines = []
    lines.append("=" * 60)
    lines.append("  CODEALPHA ANALYTICS REPORT")
    lines.append("=" * 60)
    lines.append("")

    p = data["platform"]
    lines.append(f"Platform: {p['name']}")
    lines.append(f"Tagline: {p['tagline']}")
    lines.append(f"Founded: {p['founded']}")
    lines.append(f"Headquarters: {p['headquarters']}")
    lines.append(f"LinkedIn Followers: {p['linkedin_followers']}")
    lines.append("")

    lines.append("-" * 40)
    lines.append("  SERVICES OVERVIEW")
    lines.append("-" * 40)
    lines.append(f"Internship Domains: {data['services']['total_domains']}")
    for d in data["services"]["internship_domains"]:
        lines.append(f"  - {d}")
    lines.append("")
    lines.append(f"Career Tools: {data['services']['total_tools']}")
    for t in data["services"]["career_tools"]:
        lines.append(f"  - {t}")
    lines.append("")
    lines.append(f"Key Features: {data['services']['total_features']}")
    for f in data["services"]["features"]:
        lines.append(f"  - {f}")
    lines.append("")

    lines.append("-" * 40)
    lines.append("  PLATFORM METRICS")
    lines.append("-" * 40)
    lines.append("(Note: Live counter values shown as 0 on website;")
    lines.append(" these are JS-animated counters pending backend integration)")
    lines.append("")
    lines.append("Available meta-data:")
    lines.append("  - \"Join 1M+ students\" (from meta description)")
    lines.append("  - 500K+ LinkedIn followers")
    lines.append("  - 9 internship domains offered")
    lines.append("  - 4 free AI career tools available")
    lines.append("  - 5 key platform features identified")
    lines.append("")

    lines.append("=" * 60)
    lines.append("  Generated: Web scraping + analytics pipeline")
    lines.append("=" * 60)

    report = "\n".join(lines)
    with open(os.path.join(OUTPUT_DIR, "analytics_report.txt"), "w", encoding="utf-8") as f:
        f.write(report)
    print(f"  Saved: {os.path.join(OUTPUT_DIR, 'analytics_report.txt')}")
    return report


def main():
    print("Loading CodeAlpha data...")
    data = load_data()

    print("Generating charts...")
    chart_internship_domains(data)
    chart_features_radar(data)
    chart_services_detail(data)
    chart_metrics_card(data)

    print("\nGenerating report...")
    report = generate_report(data)

    print(f"\nAll outputs saved to '{OUTPUT_DIR}/'")
    print("\n" + report)


if __name__ == "__main__":
    main()
