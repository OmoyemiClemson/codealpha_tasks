"""
CodeAlpha Analytics - Complete Pipeline Runner
Scrapes data, generates analytics dashboard and report.
"""
import asyncio
import subprocess
import sys
import os

SCRAPER = "codealpha_scraper.py"
DASHBOARD = "analytics_dashboard.py"
OUTPUT_DIR = "analytics_output"


def run():
    print("=" * 60)
    print("  CODEALPHA ANALYTICS PIPELINE")
    print("=" * 60)

    # Step 1: Scrape
    print("\n[1/2] Scraping CodeAlpha website...")
    result = subprocess.run([sys.executable, SCRAPER], capture_output=True, text=True)
    if result.returncode != 0:
        print(f"Scraper failed: {result.stderr}")
        return
    print("  Done.")

    # Step 2: Analytics
    print("\n[2/2] Generating analytics dashboard...")
    result = subprocess.run([sys.executable, DASHBOARD], capture_output=True, text=True)
    if result.returncode != 0:
        print(f"Dashboard failed: {result.stderr}")
        return
    print("  Done.\n")

    # Show outputs
    print("=" * 60)
    print("  OUTPUTS GENERATED")
    print("=" * 60)
    for f in os.listdir(OUTPUT_DIR):
        path = os.path.join(OUTPUT_DIR, f)
        size = os.path.getsize(path)
        print(f"  {f} ({size:,} bytes)")

    print("\n" + "=" * 60)
    print("  Pipeline complete!")
    print("=" * 60)


if __name__ == "__main__":
    run()
